import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'

interface AdminPageProps {}

export default function AdminPage({}: AdminPageProps) {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-primary mb-2">
              VDMA QuickPoll Admin
            </h1>
            <p className="text-muted-foreground">
              Verwalten Sie Quizzes, Fragen und Ergebnisse
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Quizzes</CardTitle>
                <CardDescription>
                  Erstellen und verwalten Sie Quiz-Umfragen
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full">
                  Quiz erstellen
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Fragen</CardTitle>
                <CardDescription>
                  Verwalten Sie Fragen und Antworten
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Fragen verwalten
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Ergebnisse</CardTitle>
                <CardDescription>
                  Analysieren Sie Quiz-Ergebnisse
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  Ergebnisse anzeigen
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Aktuelle Quizzes</CardTitle>
                <CardDescription>
                  Übersicht aller erstellten Quizzes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center text-muted-foreground py-8">
                  <p>Noch keine Quizzes erstellt</p>
                  <Button className="mt-4">
                    Erstes Quiz erstellen
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
