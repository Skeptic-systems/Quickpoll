export default function ImpressumPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Impressum</h1>
      
      <div className="prose prose-gray dark:prose-invert max-w-none">
        <h2>Angaben gemäß § 5 TMG</h2>
        <p>
          VDMA - Verband Deutscher Maschinen- und Anlagenbau e.V.<br />
          Lyoner Straße 18<br />
          60528 Frankfurt am Main<br />
          Deutschland
        </p>
        
        <h2>Kontakt</h2>
        <p>
          Telefon: +49 69 6603-0<br />
          E-Mail: info@vdma.org<br />
          Website: www.vdma.org
        </p>
        
        <h2>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h2>
        <p>
          VDMA - Verband Deutscher Maschinen- und Anlagenbau e.V.<br />
          Lyoner Straße 18<br />
          60528 Frankfurt am Main
        </p>
        
        <h2>Haftung für Inhalte</h2>
        <p>
          Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht unter der Verpflichtung, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
        </p>
        
        <h2>Haftung für Links</h2>
        <p>
          Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
        </p>
      </div>
    </div>
  )
}
