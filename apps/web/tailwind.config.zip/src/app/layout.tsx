import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@/components/theme-provider'
import { ThemeToggle } from '@/components/theme-toggle'
import { Button } from '@/components/ui/button'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'VDMA QuickPoll',
  description: 'Mobile-optimierte Quiz-Webapp mit Admin-Panel',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="de" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          defaultTheme="system"
          storageKey="vdma-quickpoll-theme"
        >
          <div className="relative min-h-screen bg-background">
            {/* Header with Logo and Theme Toggle */}
            <header className="sticky top-0 z-50 backdrop-blur-md bg-white/60 dark:bg-[#0b0f1a]/60 border-b border-white/20">
              <div className="container mx-auto px-4 py-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent-gradient rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold text-lg">Q</span>
                  </div>
                  <span className="font-bold text-xl text-gradient">QuickPoll</span>
                </div>
                <div className="flex items-center space-x-4">
                  <Button variant="ghost" size="sm">
                    Login
                  </Button>
                  <ThemeToggle />
                </div>
              </div>
            </header>
            
            <main>
              {children}
            </main>
            
            {/* Footer */}
            <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
              <div className="container mx-auto px-4 py-6">
                <div className="flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0">
                  <div className="text-sm text-muted-foreground">
                    © 2024 VDMA QuickPoll. Alle Rechte vorbehalten.
                  </div>
                  <div className="flex space-x-4 text-sm">
                    <a href="/impressum" className="text-muted-foreground hover:text-foreground">
                      Impressum
                    </a>
                    <a href="/datenschutz" className="text-muted-foreground hover:text-foreground">
                      Datenschutz
                    </a>
                  </div>
                </div>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
