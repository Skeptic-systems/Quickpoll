'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useRouter } from 'next/navigation'
import { ChartBar, QrCode, Globe, Shield, Clock, Users } from 'phosphor-react'

export default function Home() {
  const router = useRouter()

  const handleQuizStart = () => {
    // TODO: Implement quiz start logic
    alert('Quiz-Funktionalität wird implementiert!')
  }

  const handleAdminPanel = () => {
    router.push('/admin')
  }

  const scrollToQuizzes = () => {
    document.getElementById('quiz-grid')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute inset-0 bg-hero-gradient" />
        
        {/* Subtle Grid Pattern */}
        <div className="absolute inset-0 opacity-[0.06]">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            {/* Logo */}
            <div className="mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-accent-gradient rounded-2xl mb-4">
                <span className="text-white font-bold text-2xl">Q</span>
              </div>
            </div>

            {/* Headline */}
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="text-gradient">QuickPoll</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Mobile-optimierte Quiz-Webapp für Events und Umfragen
            </p>

            {/* CTA Button */}
            <Button 
              onClick={scrollToQuizzes}
              size="lg"
              className="bg-accent-gradient hover:opacity-90 text-white px-8 py-4 text-lg font-semibold hover-lift"
            >
              Aktive Quizzes ansehen
            </Button>

            {/* Decorative Icons */}
            <div className="mt-16 flex justify-center space-x-8 opacity-40">
              <ChartBar size={32} className="text-primary" />
              <QrCode size={32} className="text-accent" />
              <Globe size={32} className="text-primary" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Feature 1 */}
            <Card className="glass-card card-glow hover-lift">
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Shield size={24} className="text-primary" />
                </div>
                <CardTitle className="text-xl">Anonym</CardTitle>
                <CardDescription>
                  Keine Registrierung erforderlich.<br />
                  Datenschutz steht im Vordergrund.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Feature 2 */}
            <Card className="glass-card card-glow hover-lift">
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Clock size={24} className="text-accent" />
                </div>
                <CardTitle className="text-xl">1 Frage pro Seite</CardTitle>
                <CardDescription>
                  Fokus auf eine Frage.<br />
                  Schnelle und klare Antworten.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Feature 3 */}
            <Card className="glass-card card-glow hover-lift">
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <QrCode size={24} className="text-primary" />
                </div>
                <CardTitle className="text-xl">QR-Start</CardTitle>
                <CardDescription>
                  Einfacher Zugang per QR-Code.<br />
                  Perfekt für Events und Präsentationen.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Quiz Grid Section */}
      <section id="quiz-grid" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Aktive <span className="text-gradient">Quizzes</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Wählen Sie ein Quiz aus und starten Sie sofort
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {/* Sample Quiz Cards */}
            <Card className="glass-card card-glow hover-lift cursor-pointer" onClick={handleQuizStart}>
              <CardHeader>
                <CardTitle>VDMA Umfrage 2024</CardTitle>
                <CardDescription>
                  Allgemeine Umfrage zu aktuellen Themen
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex space-x-2">
                    <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">DE</span>
                    <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">EN</span>
                  </div>
                  <Users size={16} className="text-muted-foreground" />
                </div>
                <div className="flex space-x-2">
                  <Button className="flex-1 bg-accent-gradient hover:opacity-90">
                    Starten
                  </Button>
                  <Button variant="outline" size="sm">
                    Ergebnisse
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card card-glow hover-lift cursor-pointer" onClick={handleQuizStart}>
              <CardHeader>
                <CardTitle>Event Feedback</CardTitle>
                <CardDescription>
                  Feedback zum aktuellen Event
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex space-x-2">
                    <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">DE</span>
                  </div>
                  <Users size={16} className="text-muted-foreground" />
                </div>
                <div className="flex space-x-2">
                  <Button className="flex-1 bg-accent-gradient hover:opacity-90">
                    Starten
                  </Button>
                  <Button variant="outline" size="sm">
                    Ergebnisse
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card card-glow hover-lift cursor-pointer" onClick={handleQuizStart}>
              <CardHeader>
                <CardTitle>Produktbewertung</CardTitle>
                <CardDescription>
                  Bewertung neuer Produktfeatures
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex space-x-2">
                    <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">DE</span>
                    <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">EN</span>
                  </div>
                  <Users size={16} className="text-muted-foreground" />
                </div>
                <div className="flex space-x-2">
                  <Button className="flex-1 bg-accent-gradient hover:opacity-90">
                    Starten
                  </Button>
                  <Button variant="outline" size="sm">
                    Ergebnisse
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Admin Panel Link */}
          <div className="text-center mt-12">
            <Button 
              onClick={handleAdminPanel}
              variant="outline" 
              size="lg"
              className="hover-lift"
            >
              Admin-Panel öffnen
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
