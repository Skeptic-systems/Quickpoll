import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import { Button } from '@/components/ui'

interface QuizStartPageProps {
  params: {
    slug: string
  }
}

export default function QuizStartPage({ params }: QuizStartPageProps) {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold text-primary">
                VDMA QuickPoll
              </CardTitle>
              <CardDescription>
                Quiz: {params.slug}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <h2 className="text-lg font-semibold mb-4">
                  Sprache wählen / Choose Language
                </h2>
                <div className="space-y-3">
                  <Button 
                    className="w-full h-12 text-lg"
                    onClick={() => {
                      // TODO: Implement language selection and quiz start
                      console.log('Start quiz in German')
                    }}
                  >
                    🇩🇪 Deutsch
                  </Button>
                  <Button 
                    variant="outline"
                    className="w-full h-12 text-lg"
                    onClick={() => {
                      // TODO: Implement language selection and quiz start
                      console.log('Start quiz in English')
                    }}
                  >
                    🇬🇧 English
                  </Button>
                </div>
              </div>
              
              <div className="text-center text-sm text-muted-foreground">
                <p>15 zufällige Fragen aus einem Pool von 30</p>
                <p>15 random questions from a pool of 30</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
